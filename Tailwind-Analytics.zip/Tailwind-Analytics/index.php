<?php require_once("assets/config/config.php"); ?>
<!DOCTYPE html>
<!--[if lt IE 7]>   <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="es"> <![endif]-->
<!--[if IE 7]> 		<html class="no-js lt-ie9 lt-ie8" lang="es"> <![endif]-->
<!--[if IE 8]> 		<html class="ie8 no-js" lang="es"> <![endif]-->
<!--[if IE 9]> 		<html class="ie9 no-js" lang="es"> <![endif]-->
<!--[if !IE]><!-->
<html lang="es">
<!--<![endif]-->

<head>
     <meta charset="utf-8">
     <meta name="author" content="Alejandro Pérez-Moneo Nieto">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <meta name="description" content="">
     <title>Analytics — Landing Page</title>
     <link rel="stylesheet" href="assets/css/dist/output.css" type="text/css"/>

</head>

<body class="container max-w-screen-2xl mx-auto">
     <?php include("assets/templates/header.php"); ?>
     <main>
          <section class="max-w-full grid grid-cols-2 bg-no-repeat bg-personalized h-personalized" style="background-image:url('assets/images/rectangle-section-1.png')">
               <div class="p-44">
                    <h1 class="text-white text-4xl font-bold font-roboto">Monitor your business on real-time dashboard</h1>
                    <p class="text-gray_let text-lg font-normal font-roboto mt-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Elementum nisi aliquet volutpat pellentesque volutpat est. Sapien in etiam vitae nibh nunc mattis imperdiet sed nullam. </p>
                    <button class="rounded-full bg-rose-600 p-button-sector mt-12 text-white text-lg font-normal font-roboto">Try for free</button>
               </div>
               <img class="bg-center" src="assets\images\main-screenDoble.svg" alt="">
          </section>
          <section class="text-center">
               <h2 class="text-blue_950 text-4xl font-bold font-roboto">Main Features</h2>
               <p class="text-gray_let text-lg font-normal font-roboto mt-5">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Elementum nisi aliquet volutpat pellentesque volutpat est. Sapien in etiam vitae nibh nunc mattis imperdiet sed nullam. Vitae et, tortor pulvinar risus pulvinar sit amet. Id vel in nam malesuada.</p>
               <div class="grid grid-cols-3 mt-10 mb-32">
                    <div>
                         <img class="ml-48" src="assets\images\reloj.png" alt="">
                         <h3 class="text-blue_950 text-base font-bold font-roboto mt-9">Monitoring 24/7</h3>
                         <p class="text-gray_let text-base font-normal font-roboto mt-5">Lorem ipsum dolor sit amet, consectetur adipis cing elit. Elementum nisi aliquet volutpat.</p>
                    </div>
                    <div>
                         <img class="ml-48" src="assets\images\pc.png" alt="">
                         <h3 class="text-blue_950 text-base font-bold font-roboto mt-9">Widget System</h3>
                         <p class="text-gray_let text-base font-normal font-roboto mt-5">Sapien in etiam vitae nibh nunc mattis imperdiet sed nullam. Vitae et, tortor pulvinar risus pulvinar.</p>
                    </div>
                    <div>
                         <img class="ml-48" src="assets\images\cohete.png" alt="">
                         <h3 class="text-blue_950 text-base font-bold font-roboto mt-9">Best Performance</h3>
                         <p class="text-gray_let text-base font-normal font-roboto mt-5">Lorem ipsum dolor sit amet, consectetur adipis cing elit. Elementum nisi aliquet volutpat.</p>
                    </div>
               </div>
          </section>
          <section class="grid grid-cols-2 mt-32">
               <div class="p-40">
                    <h2 class="text-blue_950 text-4xl font-bold font-roboto">Automated Reports & Widget Alerts</h2>
                    <p class="text-gray_let text-lg font-normal font-roboto mt-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Elementum nisi aliquet volutpat pellentesque volutpat est. Sapien in etiam vitae nibh nunc mattis imperdiet sed nullam. Vitae et, tortor pulvinar risus pulvinar sit amet.</p>
               </div>
               <img src="assets\images\screen-01.svg" alt="" srcset="">
          </section>
          <section class="grid grid-cols-2">
               <img src="assets\images\screen-02.svg" alt="" srcset="">
               <div class="p-40">
                    <h2 class="text-blue_950 text-4xl font-bold font-roboto">Fully customizable to address your needs</h2>
                    <p class="text-gray_let text-lg font-normal font-roboto mt-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Elementum nisi aliquet volutpat pellentesque volutpat est. Sapien in etiam vitae nibh nunc mattis imperdiet sed nullam. Vitae et, tortor pulvinar risus pulvinar sit amet.</p>
               </div>
          </section>
          <section class="grid grid-cols-2">
               <div class="p-40 ">
                    <h2 class="text-blue_950 text-4xl font-bold font-roboto">Pre-built Dashboard Templates</h2>
                    <p class="text-gray_let text-lg font-normal font-roboto mt-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Elementum nisi aliquet volutpat pellentesque volutpat est. Sapien in etiam vitae nibh nunc mattis imperdiet sed nullam. Vitae et, tortor pulvinar risus pulvinar sit amet.</p>
               </div>
               <img src="assets\images\screen-03.svg" alt="" srcset="">
          </section>
          <section class=" max-w-full bg-no-repeat bg-personalized h-personalized-2 p-56" style="background-image:url('assets/images/rectangle-section-6.png')">
               <h2 class=" text-white text-4xl font-bold font-roboto text-center">Pricing Plans</h2>
               <p class="text-gray_let text-lg font-normal font-roboto mt-4 text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Elementum nisi aliquet volutpat pellentesque volutpat est. </p>
               <div class="grid grid-cols-3 text-center gap-20">
                    <div class="mt-20 rounded-lg bg-blue_dark h-96">
                         <h3 class="text-white text-4xl font-bold font-roboto text-center mt-12">Starter</h3>
                         <span class="text-gray_let text-lg font-normal font-roboto mt-2 border-b-2 border-blue_border">up to 3 users</span>
                         <div class="flex flex-col ">
                              <span class="text-white text-6xl font-bold font-roboto mt-9 ">$29</span>
                              <span class="text-gray_let text-lg font-normal font-roboto">per month</span>
                         </div>
                         <button class="rounded-full p-button-sector border border-blue_border text-white text-lg font-normal font-roboto mt-10">Order</button>
                    </div>
                    <div class="mt-20 rounded-lg bg-white h-96">
                         <h3 class="text-blue_950 text-4xl font-bold font-roboto mt-12">Standard</h3>
                         <span class="text-gray_let text-lg font-normal font-roboto mt-2 border-b-2 border-blue_border">up to 20 users</span>
                         <div class="flex flex-col">
                              <span class="text-blue_950 text-6xl font-bold font-roboto mt-9">$99</span>
                              <span class="text-gray_let text-lg font-normal font-roboto">per month</span>
                         </div>
                         <button class="rounded-full bg-rose-600 p-button-sector mt-10 text-white text-lg font-normal font-roboto">Order</button>
                    </div>
                    <div class="mt-20 rounded-lg bg-blue_dark h-96">
                         <h3 class="text-white text-4xl font-bold font-roboto text-center mt-12">Premium</h3>
                         <span class="text-gray_let text-lg font-normal font-roboto mt-2 border-b-2 border-blue_border">up to 200 users</span>
                         <div class="flex flex-col">
                              <span class="text-white text-6xl font-bold font-roboto mt-9 ">$299</span>
                              <span class="text-gray_let text-lg font-normal font-roboto">per month</span>
                         </div>
                         <button class="rounded-full p-button-sector border border-blue_border text-white text-lg font-normal font-roboto mt-10">Order</button>
                    </div>
               </div>
          </section>
     </main>
     <?php include("assets/templates/footer.php"); ?>
     <script src="assets/js/custom.js"></script>
</body>
</html>