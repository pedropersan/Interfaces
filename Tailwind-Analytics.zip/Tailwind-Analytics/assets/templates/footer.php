<footer class="container max-w-screen-2xl mx-auto grid grid-cols-3  p-14 bg-blue_950 border-t-2 border-blue_border bg-right-bottom bg-personalized-substract-footer bg-no-repeat" style="background-image: url('assets/images/substract-footer.png');">
    <img class="ml-16" src="assets\images\logoFooter.svg" alt="">
    <ul class="flex justify-center gap-8 text-gray_let text-lg font-normal font-roboto">
        <li><a href="#">Products</a></li>
        <li><a href="#">Pricing Plans</a></li>
        <li><a href="#">FAQ</a></li>
        <li><a href="#">Blog</a></li>
    </ul>
    <div class="flex justify-end gap-10 mr-16">
        <a href="#"><img src="assets\images\Facebook.svg" alt="" srcset=""></a>
        <a href="#"><img src="assets\images\Twitter.svg" alt="" srcset=""></a>
        <a href="#"><img src="assets\images\Instagram.svg" alt="" srcset=""></a>    
    </div>
</footer>

