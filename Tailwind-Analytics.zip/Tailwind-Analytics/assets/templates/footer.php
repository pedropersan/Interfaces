<footer>
    <img src="assets\images\logoFooter.svg" alt="">
    <ul>
        <li><a href="#">Products</a></li>
        <li><a href="#">Pricing Plans</a></li>
        <li><a href="#">FAQ</a></li>
        <li><a href="#">Blog</a></li>
    </ul>
    <div>
        <a href="#"><img src="assets\images\Facebook.svg" alt="" srcset=""></a>
        <a href="#"><img src="assets\images\Twitter.svg" alt="" srcset=""></a>
        <a href="#"><img src="assets\images\Instagram.svg" alt="" srcset=""></a>    
    </div>
</footer>

