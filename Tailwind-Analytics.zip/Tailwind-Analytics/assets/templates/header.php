<header class="container max-w-screen-2xl mx-auto grid grid-cols-2 justify-between bg-blue_950 p-5">
        <div class="grid grid-cols-2">
        <img class="ml-36" src="assets\images\logo.png" alt="">
            <nav class="-ml-1">
                <ul class="flex justify-start gap-8 text-gray_let text-lg font-normal font-roboto">
                    <li><a href="#">Products</a></li>
                    <li><a href="#">Pricing</a></li>
                    <li><a href="#">FAQ</a></li>
                    <li><a href="#">Blog</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </nav>
        </div>
        <div class="flex justify-end gap-10 text-gray_let text-lg font-normal font-roboto mr-17">
        <button class="no-border">Sign in</button>
        <button class="rounded-full p-button-sector border border-blue2_border">Sign Up</button>
        </div>
</header>

