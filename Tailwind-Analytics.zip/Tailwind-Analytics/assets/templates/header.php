<header class="container max-w-screen-2xl mx-auto bg-transparent grid grid-cols-2 justify-between content-center py-14">
    <div class="grid grid-cols-2">
    <img src="assets\images\logo-footer.png" alt="">
    <nav>
        <ul>
            <li class="mr-6"><a href="#">Products</a></li>
            <li><a href="#">Pricing</a></li>
            <li><a href="#">FAQ</a></li>
            <li><a href="#">Blog</a></li>
            <li><a href="#">Blog</a></li>
        </ul>
    </nav>
    </div>
    <div>
        <button class="no-border">Sign in</button>
        <button>Sign Up</button>
    </div>
</header>

