/** @type {import('tailwindcss').Config} */
export default {
  content: [
    './*.{html,php}',
    './assets/templates/*.{html,php}',
    './assets/js/*.{html,js}'
  ],
  theme: {
    extend: {
      maxWidth:{
        'screen-2x1':'1600px',
        'screen-x1':'1180px',
      },
      colors:{
        blue_950:'#172755',
        gray_let:'#8794BA'
      },
      backgroundColor:{
        blue_dark:'#0F1F4B',
        blue_950:'#172755'
      },
      fontFamily:{
        'roboto':['Roboto']
      },
      borderColor:{
        blue_border:'#2A4070',
        blue2_border:'#465B95'
      },
      backgroundSize: {
          'auto': 'auto',
          'cover': 'cover',
          'contain': 'contain',
          'personalized': '96rem',
          'personalized-substract-footer':'60.1rem 41rem',
      },
      backgroundPosition:{
          'personalizedPosition':'0rem 50rem',

      },
      spacing:{
        'personalized':'49rem',
        'personalized-2':'60rem',
      },
      padding:{
        'button-sector':'10px 80px'
      },
      margin:{
        '17':'9rem'
      }
    },
  },
  plugins: [],
}

