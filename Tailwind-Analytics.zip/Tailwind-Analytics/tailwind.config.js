/** @type {import('tailwindcss').Config} */
export default {
  content: [
    './*.{html,php}',
    './assets/templates/*.{html,php}',
    './assets/js/*.{html,js}'
  ],
  theme: {
    extend: {
      maxWidth:{
        'screen-2x1':'1600px',
        'screen-x1':'1180px',
      }
    },
  },
  plugins: [],
}

